package com.honeyTokens.honeyTokens_cli.commands.createCommands;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.shell.command.annotation.Command;
import org.springframework.shell.command.annotation.Option;

import com.honeyTokens.honeyTokens_cli.dtos.TokenCreationContext;
import com.honeyTokens.honeyTokens_cli.tokensServices.TokenGeneratorService;

// clase comando para el token tipo word
@Command(group = "Token Creation")
public class CreateWordCommand extends AbstractCreateCommand {
    

    @Autowired 
    public CreateWordCommand(Map<String,TokenGeneratorService> services) {
        super(services);
    }

    // comando: "generate Word", argumentos: mail(siempre), mensaje.
    @Command(command = "generate word",group = "Token Creation", description = "comando para generar honeyToken tipo Word")
    public void generateHoneyTokenWord(@Option(longNames = "mail",required = true) String mail,
    @Option(longNames = "message", defaultValue = "Atención! Se activó un WebImageToken") String message){

         TokenCreationContext context = new TokenCreationContext
        .Builder()
        .mail(mail)
        .message(message)
        .build();

        super.execute("wordTokenService", context);

    }

}
