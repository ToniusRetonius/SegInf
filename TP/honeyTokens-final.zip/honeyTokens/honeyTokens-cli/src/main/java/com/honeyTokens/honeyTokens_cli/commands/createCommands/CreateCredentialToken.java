package com.honeyTokens.honeyTokens_cli.commands.createCommands;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.shell.command.annotation.Command;
import org.springframework.shell.command.annotation.Option;


import com.honeyTokens.honeyTokens_cli.dtos.TokenCreationContext;
import com.honeyTokens.honeyTokens_cli.tokensServices.TokenGeneratorService;

// clase comando para el token tipo Credential
@Command(group = "Token Creation")
public class CreateCredentialToken extends AbstractCreateCommand{
    
     @Autowired
    public CreateCredentialToken(Map<String,TokenGeneratorService> services){
        super(services);
    }
    // comando: "create Credentials" argumentos: mail(siempre), mensaje, nombre del archivo json a generar
     @Command(command = "generate Credentials",group = "Token Creation", description = "comando para generar honeyToken tipo fake Credentials")
    public void generateHoneyTokenQr(@Option(longNames = "mail",required = true) String mail,
    @Option(longNames = "message", defaultValue = "Atención! Se activó un QRlToken") String message,
    @Option(longNames = "nameFile",defaultValue = "secret.json") String nameFile){

       // creamos el contexto con todo lo necesario y llamamos al servicio correspondiente con 
       // la clase abstracta que contiene el execute
        TokenCreationContext context = new TokenCreationContext
        .Builder()
        .mail(mail)
        .message(message)
        .nameFileCred(nameFile)
        .build();
 
        super.execute("credentialsTokenService", context);
    }

}
