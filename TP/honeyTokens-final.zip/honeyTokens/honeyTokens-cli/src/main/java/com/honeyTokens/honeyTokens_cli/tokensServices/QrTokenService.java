package com.honeyTokens.honeyTokens_cli.tokensServices;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.honeyTokens.honeyTokens_cli.clients.TokenApiClient;
import com.honeyTokens.honeyTokens_cli.dtos.TokenCreationContext;
import com.honeyTokens.honeyTokens_cli.dtos.TokenRequest;

import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import java.awt.Color;
import javax.imageio.ImageIO;

// service concreto para crear un qrToken
// genera la url del token creado en el server, y crea una imagen png con el qr y le asigna la 
// url en cuestion para la deteccion
@Service
public class QrTokenService implements TokenGeneratorService{

    private final TokenApiClient apiClient;

     @Autowired
    public QrTokenService(TokenApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public void generate(TokenCreationContext context){

        //paso 1: post al server para obtener la url del token creado
        TokenRequest request = new TokenRequest(context.getMail(), context.getMessage(), "QR", Collections.emptyMap());
        String url = apiClient.postToServer(request);

        // paso 2: crea el qr con la url generada en paso 1
        QRCodeWriter writer = new QRCodeWriter();
        try {
            BitMatrix bitMatrix = writer.encode(url, BarcodeFormat.QR_CODE,300, 300);
            imageQRConfiguration(bitMatrix,context.getNameFileQr());

        } catch (WriterException | IOException e) {
            e.printStackTrace();
            System.out.println("error de generacion de QrToken");
        }
    }


    // metodo privado para la configuracion del qr
    private void imageQRConfiguration(BitMatrix qr, String nameFile) throws IOException{

        int qrWidth = qr.getWidth();
        int qrHeight = qr.getHeight();

        BufferedImage image = new BufferedImage(500, 500, BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics2d = image.createGraphics();
        graphics2d.setColor(Color.WHITE);
        graphics2d.fillRect(0,0,500,500);

        BufferedImage qrImage = MatrixToImageWriter.toBufferedImage(qr);
        int x = (500 - qrWidth) / 2;
        int y = (500 - qrHeight) / 2;
        graphics2d.drawImage(qrImage,x,y,null);
        graphics2d.dispose();

        Path carpeta = Path.of("generated");
        if (!Files.exists(carpeta)) {
            Files.createDirectories(carpeta);
        }

        Path pathQr = carpeta.resolve(nameFile + ".png");
        ImageIO.write(image, "PNG", pathQr.toFile());
        System.out.println("QR generado en: " + pathQr.toAbsolutePath());

        

    }
}
