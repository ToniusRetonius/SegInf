package com.honeyTokens.honeyTokens_cli.tokensServices;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.Collections;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import com.honeyTokens.honeyTokens_cli.clients.TokenApiClient;
import com.honeyTokens.honeyTokens_cli.dtos.TokenCreationContext;
import com.honeyTokens.honeyTokens_cli.dtos.TokenRequest;
import com.utils.FileSaver;

// servicio concreto para crear un wordToken
// es parecido al webImage token, la idea es que al abrir el word, busque externamente una imagen
// por url con endpoint en el server y ahi detecte que se entró al archivo y generar la alerta
// y el server devuelve la imagen.

// para poder lograrlo necesitamos un template .docx y una img generica en el server
@Service
public class WordTokenService implements TokenGeneratorService {

    private final TokenApiClient apiClient;

    @Autowired
    public WordTokenService(TokenApiClient apiClient) {
        this.apiClient = apiClient;
    }

    @Override
    public void generate(TokenCreationContext context) {
        // paso 1: hacemos el post y obtenemos la url del token y la devolvemos al usuario
        TokenRequest request = new TokenRequest(context.getMail(), context.getMessage(), "WORD",Collections.emptyMap());
        String imageUrl = apiClient.postToServer(request);
        try{
        // paso 2: establecemos el outputpath para la creacion del .docx
        Path outputPath = FileSaver.resolveOutputPath("confidencial.docx");
        // paso 3: lo generamos
        createTrapDoc("templates/template.docx",outputPath.toFile().getAbsolutePath() , imageUrl);
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    // metodo privado para la creacion del .docx
    // la idea es: hace un stream del template y del output con la siguiente idea:
    // si es un directorio: lo dejamos como esta
    // si es un archivo .rels: modificamos con regex el target de la imagen asi la busca externamente 
    private void createTrapDoc(String inputPath, String outputPath, String imageUrl) throws IOException {
        
        ClassPathResource resource = new ClassPathResource(inputPath);

        try (InputStream fis = resource.getInputStream();
             ZipInputStream zipIn = new ZipInputStream(fis);
             FileOutputStream fos = new FileOutputStream(outputPath);
             ZipOutputStream zipOut = new ZipOutputStream(fos)) {

            ZipEntry entry = zipIn.getNextEntry();

            while (entry != null) {
                String entryName = entry.getName();
                
                // 1. Escribimos el manifiesto del archivo/carpeta
                zipOut.putNextEntry(new ZipEntry(entryName));
                
                // 2. Manejo de Directorios (Cerramos la entrada, no hay contenido para escribir)
                if (entry.isDirectory()) {
                    zipOut.closeEntry();
                    entry = zipIn.getNextEntry();
                    continue;
                }

                // 3. INYECCIÓN (Si es un archivo de relaciones)
                if (entryName.endsWith(".rels")) {
                    String xmlContent = new String(zipIn.readAllBytes());
                    
                    // Regex busca Target="media/cualquiercosa.png" y lo sustituye
                    String modifiedXml = xmlContent.replaceAll(
                        "Target=\"media/.*?.(png|jpg|jpeg)\"",
                        "Target=\"" + imageUrl + "\" TargetMode=\"External\"" 
                    );

                    zipOut.write(modifiedXml.getBytes());
                } else {
                    // 4. COPIA (Archivos que no son .rels)
                    zipIn.transferTo(zipOut);
                }
                
                // 5. Cierre y avance
                zipIn.closeEntry(); 
                zipOut.closeEntry(); 
                entry = zipIn.getNextEntry();
            }
        }
    }
}    
