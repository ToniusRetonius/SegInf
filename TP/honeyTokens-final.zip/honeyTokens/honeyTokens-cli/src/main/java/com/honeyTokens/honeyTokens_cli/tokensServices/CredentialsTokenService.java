package com.honeyTokens.honeyTokens_cli.tokensServices;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.honeyTokens.honeyTokens_cli.clients.TokenApiClient;
import com.honeyTokens.honeyTokens_cli.dtos.TokenCreationContext;
import com.honeyTokens.honeyTokens_cli.dtos.TokenRequest;
import com.utils.FileSaver;

// servicio concreto para crear un CredentialToken
// le pide la url al server despues de crear el token, crea el json y pone como contraseña 
// el tokenId y la url el endpoint correspondiente para la deteccion del token
@Service
public class CredentialsTokenService implements TokenGeneratorService {
    
    private final TokenApiClient apiClient;

    @Autowired
    public CredentialsTokenService(TokenApiClient apiClient){
        this.apiClient = apiClient;
    }

    @Override
    public void generate(TokenCreationContext context){
       try{ 
        // paso 1: hace el post para recibir la url del token creado
        TokenRequest request = new TokenRequest(context.getMail(), context.getMessage(), "CRED", Collections.emptyMap());
        String url = apiClient.postToServer(request);
        // extraemos el tokenId con regex de la url 
        String tokenId = extractUuid(url);
        // paso 2: creamos el json a devolver con la url el endpoint de deteccion
        String fileContent = """
                {
                    "app_name": "Corporate ERP Production",
                    "version": "v2.4.1-stable",
                    "auth_config": {
                        "portal_url": "%s",
                        "admin_username": "sysadmin",
                        "admin_password": "%s",
                        "timeout_ms": 5000
                    }
                }
                """.formatted("http://localhost:8081/portal/login", tokenId);
                
        // ponemos de nombre el nombre pasado por opcion
        String filename = context.getNameFileCred();
        if (!filename.endsWith(".json")) filename += ".json";

        // obtenemos el path con el fileSaver para la ubicacion final del json
        Path outputPath = FileSaver.resolveOutputPath(filename);

        // paso 3: escribimos el json en el path
        Files.writeString(outputPath, fileContent);
        
       } catch(Exception e){
            e.printStackTrace();
       }
    }

    // usamos regex para extraer el tokenId de la url generada
    private String extractUuid(String text) {
        // Patrón estándar para detectar un UUID v4 (xxxxxxxx-xxxx-...)
        Pattern uuidPattern = Pattern.compile("[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}");
        Matcher matcher = uuidPattern.matcher(text);
        
        if (matcher.find()) {
            return matcher.group(); // Devuelve lo que encontró (el UUID)
        }
        throw new RuntimeException("No se pudo encontrar un UUID válido en la respuesta del servidor: " + text);
    }
}
