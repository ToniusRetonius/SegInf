package com.honeyTokens.honeyTokens_cli.commands.createCommands;

import java.io.File;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.shell.command.annotation.Command;
import org.springframework.shell.command.annotation.Option;

import com.honeyTokens.honeyTokens_cli.dtos.TokenCreationContext;
import com.honeyTokens.honeyTokens_cli.tokensServices.TokenGeneratorService;

// clase comando para el token tipo webImage
@Command(group = "Token Creation")
public class CreateWebImageCommand extends AbstractCreateCommand {
    

    @Autowired 
    public CreateWebImageCommand(Map<String,TokenGeneratorService> services) {
        super(services);
    }

    // comando: "generate webImage", argumentos: mail(siempre), mensaje, imagen a devolver
    @Command(command = "generate webImage",group = "Token Creation", description = "comando para generar honeyToken tipo WebImage")
    public void generateHoneyTokenWebImage(@Option(longNames = "mail",required = true) String mail,
    @Option(longNames = "message", defaultValue = "Atención! Se activó un WebImageToken") String message,
    @Option(longNames = "image", required = true) File imageFile){
        
        // creamos el contexto con todo lo necesario y llamamos al servicio correspondiente con 
        // la clase abstracta que contiene el execute
        TokenCreationContext context = new TokenCreationContext
        .Builder()
        .mail(mail)
        .message(message)
        .image(imageFile)
        .build();

        super.execute("webImageTokenService", context);

    }

}
