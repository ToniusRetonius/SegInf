package com.utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;


// clase util para guardar los archivos generados en una carpeta llamada generated
public class FileSaver {
    
    public static Path resolveOutputPath(String fileName) throws IOException {
        Path carpeta = Path.of("generated");
        

        if (!Files.exists(carpeta)) {
            Files.createDirectories(carpeta);
        }

        return carpeta.resolve(fileName);
    }
    
}
