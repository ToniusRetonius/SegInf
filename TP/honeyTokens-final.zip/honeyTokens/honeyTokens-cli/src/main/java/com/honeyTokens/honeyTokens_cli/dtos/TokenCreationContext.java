package com.honeyTokens.honeyTokens_cli.dtos;

import java.io.File;

// clase para guardar los datos necesarios para crear un token
// con builder para crearlo dependiendo el tipo de token y lo que necesita
public class TokenCreationContext {
    
    // datos comunes
    private final String mail;
    private final String message;


    //datos particulares
    // webImage
    private final File image;
    
    //qr
    private final String nameFileQr;

    //Credentials
    private final String nameFileCred;

    // constructor privado para el builder
    private TokenCreationContext(Builder builder) {
        this.mail = builder.mail;
        this.message = builder.message;
        this.image= builder.image;
        this.nameFileQr = builder.nameFileQr;
        this.nameFileCred = builder.nameFileCred;
    }
    
    //getters
    public String getMail() { return mail; }
    public String getMessage() { return message; }
    public File getImage() { return image; }
    public String getNameFileQr() { return nameFileQr; }
    public String getNameFileCred() { return nameFileCred; }

    //builder
    public static class Builder {
        private String mail;
        private String message;
        private File image;
        private String nameFileQr;
        private String nameFileCred;

        public Builder mail(String mail) {
            this.mail = mail;
            return this;
        }

        public Builder message(String message) {
            this.message = message;
            return this;
        }

        public Builder image(File image) {
            this.image = image;
            return this;
        }

        public Builder nameFileQr(String nameFileQr){
            this.nameFileQr = nameFileQr;
            return this;
        }

        public Builder nameFileCred(String nameFileCred){
            this.nameFileCred = nameFileCred;
            return this;
        }

        public TokenCreationContext build(){
            return new TokenCreationContext(this);
        }
        
    }

    public static Builder builder() {
        return new Builder();
    }

}
