package com.honeyTokens.honeyTokens_cli.tokensServices;

import com.honeyTokens.honeyTokens_cli.dtos.TokenCreationContext;

// interfaz para los servicios de creacion de tokens
public interface TokenGeneratorService {
    
    void generate(TokenCreationContext context);


}
