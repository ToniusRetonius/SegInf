package com.honeyTokens.honeyTokens_cli.dtos;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

// clase para transportar la respuesta del server para el cli
// usamos jackson tambien, devuelve solo el url del token
public class TokenResponse {
    
    private final String finalUrl;
    

    @JsonCreator
    public TokenResponse(@JsonProperty("url") String url){
        this.finalUrl = url;
    }

    public String getUrl(){return finalUrl;}
}