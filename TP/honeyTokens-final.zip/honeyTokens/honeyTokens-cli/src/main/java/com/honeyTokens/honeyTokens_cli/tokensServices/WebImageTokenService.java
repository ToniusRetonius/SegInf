package com.honeyTokens.honeyTokens_cli.tokensServices;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.honeyTokens.honeyTokens_cli.clients.TokenApiClient;
import com.honeyTokens.honeyTokens_cli.dtos.TokenCreationContext;
import com.honeyTokens.honeyTokens_cli.dtos.TokenRequest;

// servicio concreto para crear un webImage Token
// hace el post al server para que le de la url con la imagen para 
// que el server tambien la guarde para cuando entren a la url 
// devuelva la imagen en cuestion
@Service
public class WebImageTokenService implements TokenGeneratorService{
    
    private final TokenApiClient apiClient;

    @Autowired
    public WebImageTokenService(TokenApiClient apiClient){
        this.apiClient = apiClient;
    }

    public void generate(TokenCreationContext context){
        
        try{
            
            // copia directamente los bytes de la imagen pasada por agrumento
            byte[] imageBytes = processImage(context.getImage());

            // los guarda en metadata para pasarlo con el tokenRequest
            Map<String,Object> metadata = new HashMap<String,Object>();
            metadata.put("imageBytes", imageBytes);
            TokenRequest request = new TokenRequest(context.getMail(), context.getMessage(), "WEB_IMAGE", metadata);

            // hace el post y recibe la url y la devuelve
            String url = apiClient.postToServer(request);

            System.out.println("la url es " + url); 

        } catch(Exception e){
            e.printStackTrace();
        }
    }

    // metodo para extraer los bytes del file
    private byte[] processImage(File imageFile){
        try {
            return Files.readAllBytes(imageFile.toPath());
        } catch (IOException e) {
            throw new RuntimeException(" No se pudo leer el archivo de imagen.", e);
        }
        
    }
}
