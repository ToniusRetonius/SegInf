package com.utils;

import org.springframework.shell.jline.PromptProvider;
import org.springframework.stereotype.Component;
import org.jline.utils.AttributedString;

// clase util para cambiar el prompt de la CLI
@Component
public class Prompt implements PromptProvider {

    @Override
    public AttributedString getPrompt() {
        return new AttributedString("HoneyTokens:> ");
    }
}
