package com.honeyTokens.honeyTokens_cli.commands.createCommands;

import java.util.Map;
import java.util.Optional;

import com.honeyTokens.honeyTokens_cli.dtos.TokenCreationContext;
import com.honeyTokens.honeyTokens_cli.tokensServices.TokenGeneratorService;


// clase abstracta para que extiendan los comandos de creacion
// la idea es concentrar la logica de llamar al servicio correspondiente 
// dependiendo del tipo de token
public abstract class AbstractCreateCommand {
    
    // spring por defecto tiene como key el nombre de la clase con la primer letra en lowerCase
    private final Map<String, TokenGeneratorService> servicesMap;

    protected AbstractCreateCommand(Map<String, TokenGeneratorService> servicesMap) {
        this.servicesMap = servicesMap;
    }

    // metodo que busca el servicio correspondiente al tipo de token 
    // para crear el token, pasandole el contexto de creacion(lo que necesita para crearse)
    protected void execute(String tokenType, TokenCreationContext context){
        
        Optional.ofNullable(servicesMap.get(tokenType))
        .orElseThrow(() -> new IllegalArgumentException("tipo servicio invalido"))
        .generate(context); 

    }
}
