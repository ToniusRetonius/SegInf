package com.honeyTokens.honeyTokens_cli.clients;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.honeyTokens.honeyTokens_cli.dtos.TokenRequest;
import com.honeyTokens.honeyTokens_cli.dtos.TokenResponse;

// servicio para hacer el post al server
@Service
public class TokenApiClient {
    
    private final RestTemplate restTemplate;
    private final String url;

    @Autowired
    public TokenApiClient(RestTemplate restTemplate, @Value("${SERVER_URL:http://honey-server:8081}") String baseUrl){
        this.restTemplate = restTemplate;
        this.url = baseUrl + "/tokens/generate";
    }
    
    // devolvemos la url
    public String postToServer(TokenRequest request){

        TokenResponse response = restTemplate.postForObject(url, request, TokenResponse.class);
        return response.getUrl();
    }
}
