package com.honeyTokens.honeyTokens_cli.commands.createCommands;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.shell.command.annotation.Command;
import org.springframework.shell.command.annotation.Option;

import com.honeyTokens.honeyTokens_cli.dtos.TokenCreationContext;
import com.honeyTokens.honeyTokens_cli.tokensServices.TokenGeneratorService;
// clase comando para el token tipo qr
@Command(group = "Token Creation")
public class CreateQrCommand extends AbstractCreateCommand {
    

    @Autowired
    public CreateQrCommand(Map<String,TokenGeneratorService> services){
        super(services);
    }

    // comando: "create qr" argumentos: mail(siempre), mensaje, nombre del archivo png a generar con el qr
    @Command(command = " generate qr",group = "Token Creation", description = "comando para generar honeyToken tipo QR")
    public void generateHoneyTokenQr(@Option(longNames = "mail",required = true) String mail,
    @Option(longNames = "message", defaultValue = "Atención! Se activó un QRlToken") String message,
    @Option(longNames = "nameFile",defaultValue = "generatedQR") String nameFile){

        // creamos el contexto con todo lo necesario y llamamos al servicio correspondiente con 
        // la clase abstracta que contiene el execute
        TokenCreationContext context = new TokenCreationContext
        .Builder()
        .mail(mail)
        .message(message)
        .nameFileQr(nameFile)
        .build();
 
        super.execute("qrTokenService", context);
    }

}
