package com.honeyTokens.honeyTokens_cli.tokensServices;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.honeyTokens.honeyTokens_cli.clients.TokenApiClient;
import com.honeyTokens.honeyTokens_cli.dtos.TokenCreationContext;
import com.honeyTokens.honeyTokens_cli.dtos.TokenRequest;

// servicio concreto para crear un urlToken
// simplemente pide la url del token creado y la devuelve
@Service
public class UrlTokenService implements TokenGeneratorService{

    private final TokenApiClient apiClient;

    @Autowired
    public UrlTokenService(TokenApiClient apiClient){
        this.apiClient = apiClient;
    }


    public void generate(TokenCreationContext context){
        // hace el post al server y devuelve la url
        TokenRequest request = new TokenRequest(context.getMail(), context.getMessage(), "URL", Collections.emptyMap());
        String url = apiClient.postToServer(request); 
        System.out.println("la url es " + url);  
    }   

}
