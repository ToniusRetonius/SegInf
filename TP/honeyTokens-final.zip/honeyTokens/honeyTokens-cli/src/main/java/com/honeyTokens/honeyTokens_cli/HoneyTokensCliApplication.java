package com.honeyTokens.honeyTokens_cli;

import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.shell.command.annotation.CommandScan;
import org.springframework.web.client.RestTemplate;


// punto de entrada del programa
@SpringBootApplication
@ComponentScan({"com.honeyTokens.honeyTokens_cli", "com.utils"})
@CommandScan("com.honeyTokens.honeyTokens_cli.commands")
public class HoneyTokensCliApplication {

	public static void main(String[] args) {
        new SpringApplicationBuilder(HoneyTokensCliApplication.class)
            .web(WebApplicationType.NONE) 
            .run(args);
    }

	@Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

}
