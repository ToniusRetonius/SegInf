package com.honeyTokens.honeyTokens_server.services.strategies.response;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.honeyTokens.honeyTokens_server.model.Token;
import com.honeyTokens.honeyTokens_server.model.WebImageToken;

//estrategia para detectar webImageToken
@Component
public class WebImageResponseStrategy implements TokenResponseStrategy {
    
    @Override
    public boolean supports(Token token){
        return token instanceof WebImageToken;
    }

    @Override
    public ResponseEntity<?> generateResponse(Token token){
        // responde con la img guardada
        WebImageToken imageToken = (WebImageToken) token;
        byte[] imageBytes = imageToken.getImageBytes();
        return ResponseEntity.ok()
                .contentType(MediaType.IMAGE_PNG)
                .body(imageBytes);

    }

}
