package com.honeyTokens.honeyTokens_server.services.strategies.creation;

import java.util.Base64;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.honeyTokens.honeyTokens_server.dtos.TokenRequest;
import com.honeyTokens.honeyTokens_server.model.Token;
import com.honeyTokens.honeyTokens_server.model.User;
import com.honeyTokens.honeyTokens_server.model.WebImageToken;
import com.honeyTokens.honeyTokens_server.repositories.TokenRepository;
import com.honeyTokens.honeyTokens_server.services.UserService;

//estrategia para crear webImageToken
@Component
public class WebImageCreationStrategy implements TokenCreationStrategy {
    
    private final UserService userService;
    private final TokenRepository tokenRepository;
    
    @Autowired
    public WebImageCreationStrategy(UserService userService, TokenRepository tokenRepository){
        this.tokenRepository = tokenRepository;
        this.userService = userService;
    }

    public Token create(TokenRequest request){
        
        System.out.println("Request recibido: " + request.getMail() + ", " + request.getMessage());
        
        User user = userService.getOrCreateUser(request.getMail());

        // decodifica la imagen para guardar(jackson la codifica con base64)
        String base64 = (String) request.getMetadata().get("imageBytes");
        byte[] imageBytes = Base64.getDecoder().decode(base64);

        UUID tokenId = UUID.randomUUID();
        String generatedUrl = "http://localhost:8081/home/" + tokenId.toString() + "/image.png";
        Token newToken = new WebImageToken(user, generatedUrl, imageBytes,tokenId,request.getMessage());
        return tokenRepository.save(newToken);
    }

    public String getTokenType(){
        return "WEB_IMAGE";
    }
}
