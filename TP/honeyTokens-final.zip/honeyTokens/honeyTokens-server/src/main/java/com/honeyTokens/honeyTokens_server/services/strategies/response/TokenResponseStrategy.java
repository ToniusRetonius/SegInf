package com.honeyTokens.honeyTokens_server.services.strategies.response;

import org.springframework.http.ResponseEntity;

import com.honeyTokens.honeyTokens_server.model.Token;

public interface TokenResponseStrategy {
    
    boolean supports(Token token);

    ResponseEntity<?> generateResponse(Token token);
}
