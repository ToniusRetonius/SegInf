package com.honeyTokens.honeyTokens_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


// punto inicial del programa
@SpringBootApplication
public class HoneyTokensServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(HoneyTokensServerApplication.class, args);
	}

}
