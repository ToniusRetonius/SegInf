package com.honeyTokens.honeyTokens_server.dtos;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

// misma clase para recibir datos de CLI
public class TokenRequest {
    
    private final String mail;
    private final String message;
    private final String type;
    private final Map<String,Object> metadata;

    @JsonCreator
    public TokenRequest(@JsonProperty("mail") String mail,
    @JsonProperty("message") String message,
    @JsonProperty("type") String type, @JsonProperty("metadata") Map<String,Object> metadata){
        this.mail = mail;
        this.message = message;
        this.type = type;
        this.metadata = metadata;
    }


    public String getMail(){ return mail;}
    public String getMessage(){ return message;}
    public String getType(){return type;}
    public Map<String, Object> getMetadata() { return metadata; }
}
