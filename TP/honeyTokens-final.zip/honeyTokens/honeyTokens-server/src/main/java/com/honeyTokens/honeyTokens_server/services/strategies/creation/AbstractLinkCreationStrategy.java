package com.honeyTokens.honeyTokens_server.services.strategies.creation;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.honeyTokens.honeyTokens_server.dtos.TokenRequest;
import com.honeyTokens.honeyTokens_server.model.Token;
import com.honeyTokens.honeyTokens_server.model.User;
import com.honeyTokens.honeyTokens_server.repositories.TokenRepository;
import com.honeyTokens.honeyTokens_server.services.UserService;

//clase abstracta para las strategies que necesiten solo la url
public abstract class AbstractLinkCreationStrategy implements TokenCreationStrategy {
    
    private final UserService userService;
    private final TokenRepository tokenRepository;
    @Value("${APP_PUBLIC_DOMAIN:http://localhost:8081}")
    private String baseUrl;

    @Autowired
    public AbstractLinkCreationStrategy(UserService userService, TokenRepository tokenRepository){
        this.tokenRepository = tokenRepository;
        this.userService = userService;
    }

    // metodo para crear
    @Override
    public Token create(TokenRequest request){

        System.out.println("Request recibido: " + request.getMail() + ", " + request.getMessage());
        // trae el user de db si ya esta "registrado" o crea uno nuevo
        User user = userService.getOrCreateUser(request.getMail());
        // nuevo token id para el token
        UUID tokenId = UUID.randomUUID();
        // url nueva para el token (contiene su tokenId)
        String generatedUrl = baseUrl + "/home/" + tokenId.toString() + "/confidential";
        // cada strategie crea su tipo de token
        Token newToken = createRequiredToken(user, generatedUrl,tokenId,request.getMessage());
        // guarda el token y devuelve
        return tokenRepository.save(newToken);
        
    }

    protected abstract Token createRequiredToken(User user, String url, UUID tokenId, String message);

}
