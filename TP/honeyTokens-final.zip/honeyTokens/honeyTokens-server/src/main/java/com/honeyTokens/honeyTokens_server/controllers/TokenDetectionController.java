package com.honeyTokens.honeyTokens_server.controllers;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.honeyTokens.honeyTokens_server.model.Token;
import com.honeyTokens.honeyTokens_server.repositories.TokenRepository;
import com.honeyTokens.honeyTokens_server.services.alerts.AlertService;
import com.honeyTokens.honeyTokens_server.services.strategies.response.TokenResponseStrategy;

import jakarta.servlet.http.HttpServletRequest;

// controller para la deteccion de los tokens, usamos un endpoint general para todos
//(menos Credential que tiene su propio controller)
// la estructura es http://localhost:8081/home/{tokenid}/{algo mas}
@RequestMapping("/home/")
@RestController
public class TokenDetectionController {
    
   private final TokenRepository tokenRepository;
    private final AlertService alertService;
    private final List<TokenResponseStrategy> strategies; 

    @Autowired
    public TokenDetectionController(
            TokenRepository tokenRepository,
            AlertService alertService,
            List<TokenResponseStrategy> strategies) {
        this.tokenRepository = tokenRepository;
        this.alertService = alertService;
        this.strategies = strategies;
    }

    // endpoint en cuestion
    @GetMapping("/{tokenId}/{filename}")
    public ResponseEntity<?> handleActivation(@PathVariable UUID tokenId,@PathVariable String filename, HttpServletRequest request){
      // usamos el id para encontrar el token en la db
      Token token = tokenRepository.findById(tokenId)
      .orElseThrow(() -> new RuntimeException("Token inválido o inexistente"));

      // procesamos la activacion del token
      alertService.processActivation(token, request);
      // buscamos el servicio correspondiente al tipo de token y generamos la response
      return strategies.stream()
      .filter(strategy -> strategy.supports(token))
      .findFirst()
      .map(s -> s.generateResponse(token))
      .orElse(ResponseEntity.notFound().build());

    }


  
}
