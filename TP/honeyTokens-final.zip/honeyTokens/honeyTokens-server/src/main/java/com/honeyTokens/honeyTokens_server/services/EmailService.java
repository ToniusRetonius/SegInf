package com.honeyTokens.honeyTokens_server.services;

import java.io.IOException;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.sendgrid.SendGrid;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Content;
import com.sendgrid.helpers.mail.objects.Email;
import com.honeyTokens.honeyTokens_server.model.Alert;
import com.honeyTokens.honeyTokens_server.model.Token;
import com.sendgrid.Method;
import com.sendgrid.Request;
import com.sendgrid.Response;


// servicio para mandar el mail cuando se detecta un token, usamos SENDGRID
@Service
public class EmailService {
    
    
    public void sendAlertMail(Token token, Alert alert) {
      try {
          String htmlContent = """
      <html>
        <body style="font-family: Arial, sans-serif; color: #333;">
          <h2 style="color: #d9534f;">🚨 Alerta de HoneyToken Detectada</h2>
          <p><strong>Mensaje del usuario:</strong> %s</p>
          <hr>
          <h3>📋 Información del Token</h3>
          <ul>
            <li><strong>ID del Token:</strong> %s</li>
            <li><strong>URL Asociada:</strong> %s</li>
            <li><strong>Veces activado:</strong> %d</li>
          </ul>
          <h3>🌐 Detalles del Acceso</h3>
          <ul>
            <li><strong>ID de Alerta:</strong> %s</li>
            <li><strong>IP del cliente:</strong> %s</li>
            <li><strong>User-Agent:</strong> %s</li>
            <li><strong>Referer:</strong> %s</li>
            <li><strong>URL accedida:</strong> %s</li>
            <li><strong>Fecha y hora:</strong> %s</li>
          </ul>
          <hr>
          <p style="font-size: 12px; color: #777;">
            Este mensaje fue generado automáticamente por el sistema HoneyTokens Server🐝.
          </p>
        </body>
      </html>
      """.formatted(
              token.getMessage(),
              token.getTokenId(),
              token.getUrl(),
              token.getTimesActivated(),
              alert.getAlertId(),
              alert.getIpClient(),
              alert.getUserAgent(),
              Optional.ofNullable(alert.getReferer()).orElse("No disponible"),
              alert.getUrl(),
              alert.getTimeStamp()
          );
  
          sendMail(
              token.getUser().getMail(),
              "Alerta de HoneyToken",
              htmlContent
          );
  
      } catch (IOException e) {
          e.printStackTrace();
      }
  }

  private void sendMail(String to, String subject, String body) throws IOException{
    Email from = new Email("marcoromanofinaa@gmail.com");
    Email toEmail = new Email(to);
    Content content = new Content("text/html",body);
    Mail mail = new Mail(from,subject,toEmail,content);

    SendGrid sg = new SendGrid(System.getenv("KEY"));
    Request request = new Request();

    try {
        request.setMethod(Method.POST);
        request.setEndpoint("mail/send");
        request.setBody(mail.build());
        Response response = sg.api(request);

        System.out.println("Status: " + response.getStatusCode());
        System.out.println("Body: " + response.getBody());
        System.out.println("Headers: " + response.getHeaders());

    } catch (IOException e) {
        e.printStackTrace();
    }


    }

}
