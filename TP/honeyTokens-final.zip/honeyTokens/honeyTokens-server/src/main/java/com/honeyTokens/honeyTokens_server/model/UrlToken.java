package com.honeyTokens.honeyTokens_server.model;

import java.util.UUID;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("URL")
public class UrlToken extends Token {

    public UrlToken() {}

    public UrlToken(User user, String url, UUID tokenId, String message) {
        super(user, url, tokenId, message);
    }
}
