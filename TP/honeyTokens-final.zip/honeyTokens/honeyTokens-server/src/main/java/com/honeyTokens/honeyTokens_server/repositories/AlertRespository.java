package com.honeyTokens.honeyTokens_server.repositories;

import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.honeyTokens.honeyTokens_server.model.Alert;
import com.honeyTokens.honeyTokens_server.model.Token;

// repositorio de alertas
@Repository
public interface AlertRespository extends JpaRepository<Alert,UUID>{
    
    List<Alert> findByToken(Token token);
   
}
