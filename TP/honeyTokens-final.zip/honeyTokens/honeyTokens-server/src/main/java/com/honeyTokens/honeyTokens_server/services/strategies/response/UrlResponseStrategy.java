package com.honeyTokens.honeyTokens_server.services.strategies.response;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;


import com.honeyTokens.honeyTokens_server.model.Token;
import com.honeyTokens.honeyTokens_server.model.UrlToken;

//estrategia para detectar urlToken
@Component
public class UrlResponseStrategy implements TokenResponseStrategy {
    
    
    @Override
    public boolean supports(Token token){
        return token instanceof UrlToken;
    }

    @Override
    public ResponseEntity<?> generateResponse(Token token){
        
        String fakeErrorHtml = """
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>403 Forbidden</title>
                <style>
                    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; text-align: center; padding: 50px; background-color: #f4f4f4; }
                    .container { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); max-width: 600px; margin: auto; }
                    h1 { color: #d9534f; font-size: 24px; margin-bottom: 10px; }
                    p { color: #555; font-size: 16px; line-height: 1.5; }
                    .error-code { font-size: 12px; color: #999; margin-top: 20px; border-top: 1px solid #eee; padding-top: 10px; }
                    .ip-log { font-family: monospace; background: #eee; padding: 5px; border-radius: 4px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>⛔ Access Denied</h1>
                    <p>You do not have permission to access the requested resource on this server.</p>
                    <p>Your access attempt has been logged due to security policies.</p>
                    <p><strong>Incident ID:</strong> <span class="ip-log">%s</span></p>
                    <div class="error-code">Error Code: 403-FORBIDDEN | Server: Auth-Gateway-v2</div>
                </div>
            </body>
            </html>
            """.formatted(token.getTokenId()); // Inyectamos el ID para darle "realismo" técnico

        return ResponseEntity
                .status(403) // El código HTTP correcto para "Prohibido"
                .contentType(MediaType.TEXT_HTML) // Importante para que el navegador renderice el HTML
                .body(fakeErrorHtml);

    }
}
