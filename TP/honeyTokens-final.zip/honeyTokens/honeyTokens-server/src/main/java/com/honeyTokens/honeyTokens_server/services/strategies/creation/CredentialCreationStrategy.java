package com.honeyTokens.honeyTokens_server.services.strategies.creation;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.honeyTokens.honeyTokens_server.model.CredentialToken;
import com.honeyTokens.honeyTokens_server.model.Token;
import com.honeyTokens.honeyTokens_server.model.User;
import com.honeyTokens.honeyTokens_server.repositories.TokenRepository;
import com.honeyTokens.honeyTokens_server.services.UserService;

// strategie para crear CredentialToken
@Component
public class CredentialCreationStrategy extends AbstractLinkCreationStrategy{
    
    @Autowired
    public CredentialCreationStrategy(UserService userService, TokenRepository tokenRepository){
       super(userService, tokenRepository);
    }

    @Override
    public String getTokenType(){
        return "CRED";
    }

    @Override
    public Token createRequiredToken(User user, String url, UUID tokenId, String message){
        return new CredentialToken(user, url,tokenId, message);
    }
}
