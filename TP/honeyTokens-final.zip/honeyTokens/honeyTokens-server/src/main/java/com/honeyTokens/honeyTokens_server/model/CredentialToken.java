package com.honeyTokens.honeyTokens_server.model;

import java.util.UUID;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

// modelado de CredentialToken
@Entity
@DiscriminatorValue("CRED")
public class CredentialToken extends Token{
    
     public CredentialToken() {}

    public CredentialToken(User user, String url, UUID tokenId, String message) {
        super(user, url, tokenId, message);
    }

}
