package com.honeyTokens.honeyTokens_server.services.strategies.response;

import java.io.InputStream;

import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;

import com.honeyTokens.honeyTokens_server.model.Token;
import com.honeyTokens.honeyTokens_server.model.WordToken;

//estrategia para detectar wordToken
@Component
public class WordResponseStrategy implements TokenResponseStrategy {

   @Override
    public boolean supports(Token token){
        return token instanceof WordToken;
    }

    @Override
    public ResponseEntity<?> generateResponse(Token token){
        
        
        try{
            ClassPathResource resource = new ClassPathResource("static/image1.png");

            try (InputStream inputStream = resource.getInputStream()) {
                byte[] imageBytes = StreamUtils.copyToByteArray(inputStream);

                // devuelve la imagen del template siempre
                return ResponseEntity.ok()
                        .contentType(MediaType.IMAGE_PNG)
                        .body(imageBytes);
            }
        } catch(Exception e){
            System.err.println("Error al servir el logo de Word: " + e.getMessage());
            return ResponseEntity.notFound().build();
        } 

    }

}
