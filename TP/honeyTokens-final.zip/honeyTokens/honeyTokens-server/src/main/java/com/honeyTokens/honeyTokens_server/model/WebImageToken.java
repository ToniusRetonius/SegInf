package com.honeyTokens.honeyTokens_server.model;

import java.util.UUID;

import jakarta.persistence.Basic;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Lob;

// modelado de webImageToken
@Entity
@DiscriminatorValue("WEB_IMAGE")
public class WebImageToken extends Token {
    
    @Lob
    @Basic(fetch = FetchType.LAZY)
    private byte[] imageBytes;

    public WebImageToken(User user, String url, byte[] imageBytes, UUID tokenId, String message) {
        super(user, url,tokenId,message);
        this.imageBytes = imageBytes;
    }

    public WebImageToken(){}


    public byte[] getImageBytes() { return imageBytes;}
    public void setImageBytes(byte[] imageBytes) { this.imageBytes = imageBytes;}

}
