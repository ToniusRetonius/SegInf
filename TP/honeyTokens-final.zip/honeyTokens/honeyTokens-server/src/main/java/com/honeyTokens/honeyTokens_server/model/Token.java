package com.honeyTokens.honeyTokens_server.model;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.DiscriminatorType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


@Entity
@Table(name = "tokens")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type", discriminatorType = DiscriminatorType.STRING)
public class Token {

      @Id
      @Column(unique = true)
      private UUID tokenId;

      @ManyToOne
      @JoinColumn(name = "userId", nullable = false)
      private User user;

      private String url;
      private int timesActivated;
      private ZonedDateTime creationDate;
      private String message;

      @OneToMany(mappedBy = "token", cascade = CascadeType.ALL, orphanRemoval = true)
      private List<Alert> history = new ArrayList<Alert>();


      // constructor vacio
      public Token(){}

      // constructor
      public Token(User user, String url, UUID tokenId, String message){
        this.user = user;
        this.url = url;
        this.tokenId = tokenId;
        this.creationDate = ZonedDateTime.now();
        this.timesActivated = 0;
        this.message = message;
      }

      public void registerActivation(Alert alert){
        timesActivated += 1;
        this.history.add(alert);
      }

      // getters y setters
      
      public UUID getTokenId() { return tokenId; }
      public void setTokenId(UUID tokenId) { this.tokenId = tokenId; }

      public User getUser() { return user; }
      public void setUser(User user) { this.user = user; }

      public String getUrl() { return url; }
      public void setUrl(String url) { this.url = url; }

      public String getMessage() { return message; }
      public void setMessage(String message) { this.message = message; }

      public int getTimesActivated() { return timesActivated; }
      public void setTimesActivated(int timesActivated) { this.timesActivated = timesActivated; }

      public ZonedDateTime getCreationDate() { return creationDate; }
      public void setCreationDate(ZonedDateTime creationDate) { this.creationDate = creationDate; }

      public List<Alert> getHistory() { return history; }
      public void setHistory(List<Alert> history) { this.history = history; }

}