package com.honeyTokens.honeyTokens_server.controllers;

import java.io.IOException;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.honeyTokens.honeyTokens_server.model.CredentialToken;
import com.honeyTokens.honeyTokens_server.model.Token;
import com.honeyTokens.honeyTokens_server.repositories.TokenRepository;
import com.honeyTokens.honeyTokens_server.services.alerts.AlertService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

//controlador para detectar tokens de tipo Credentials
// tiene dos endpoints, uno devuelve la pagina de login, 
// y el otro verifica si es un CredentialToken(si la contraseña es un CredentialtokenID)
// en ambos casos, le dice al usuario error de contraseña/usuario
@Controller
public class FakeLoginController {
    
    private final TokenRepository tokenRepository;
    private final AlertService alertService;

    @Autowired
    public FakeLoginController(TokenRepository tokenRepository, AlertService alertService) {
        this.tokenRepository = tokenRepository;
        this.alertService = alertService;
    }

    // devuelve html para el login (guardado en resources/static)
    @GetMapping("/portal/login")
    public ResponseEntity<byte[]> showLoginPage() throws IOException {
        ClassPathResource resource = new ClassPathResource("static/fakeLogin.html");
        
        
        return ResponseEntity.ok()
                .contentType(MediaType.TEXT_HTML)
                .body(resource.getInputStream().readAllBytes());
    }

    // detecta el token y procesa la alerta
    @PostMapping("/api/v1/internal/auth")
    public void attemptLogin(
        @RequestParam String username,
        @RequestParam String password, 
        HttpServletRequest request,
        HttpServletResponse response) throws IOException{
            try{
                UUID potentialTokenId = UUID.fromString(password.trim());
                Optional<Token> tokenOpt = tokenRepository.findById(potentialTokenId);
                if (tokenOpt.isPresent() && tokenOpt.get() instanceof CredentialToken) {

                    alertService.processActivation(tokenOpt.get(), request);
                }
            
            } catch(IllegalArgumentException e){

            }
            response.sendRedirect("/portal/login?error=true");
    }
    

}
