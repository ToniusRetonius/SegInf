package com.honeyTokens.honeyTokens_server.services.strategies.creation;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.honeyTokens.honeyTokens_server.model.Token;
import com.honeyTokens.honeyTokens_server.model.UrlToken;
import com.honeyTokens.honeyTokens_server.model.User;
import com.honeyTokens.honeyTokens_server.repositories.TokenRepository;
import com.honeyTokens.honeyTokens_server.services.UserService;

//estrategia para crear urlToken
@Component
public class UrlCreationStrategy extends AbstractLinkCreationStrategy {

    @Autowired
    public UrlCreationStrategy(UserService userService, TokenRepository tokenRepository){
        super(userService,tokenRepository);
    }
    
    @Override
    public Token createRequiredToken(User user, String url, UUID tokenId, String message){
        return new UrlToken(user, url,tokenId, message);
    }

    public String getTokenType(){
        return "URL";
    }
}
