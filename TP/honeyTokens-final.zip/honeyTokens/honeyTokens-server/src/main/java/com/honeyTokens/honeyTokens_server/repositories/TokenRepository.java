package com.honeyTokens.honeyTokens_server.repositories;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.honeyTokens.honeyTokens_server.model.Token;
import com.honeyTokens.honeyTokens_server.model.User;

// repositorio de tokens(guarda todos los tipos en la misma table)
@Repository
public interface TokenRepository extends JpaRepository<Token,UUID> {
    
    public List<Token> findByUser(User user);
    public List<Token> findByUser_Mail(String mail);
    public Optional<Token> findByUrl(String url);
}
