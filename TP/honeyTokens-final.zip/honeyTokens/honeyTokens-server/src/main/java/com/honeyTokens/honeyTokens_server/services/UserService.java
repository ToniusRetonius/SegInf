package com.honeyTokens.honeyTokens_server.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.honeyTokens.honeyTokens_server.model.User;
import com.honeyTokens.honeyTokens_server.repositories.UserRepository;

// servicio para la creacion o querie del usuario
@Service
public class UserService {
    
    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository){
        this.userRepository = userRepository;
    }

    public User getOrCreateUser(String mail) {
        if (userRepository.existsByMail(mail)) {
            return userRepository.findByMail(mail);
        }
        User newUser = new User(mail);
        return userRepository.save(newUser);
    }
}
