package com.honeyTokens.honeyTokens_server.model;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

//modelado de User(dueños de tokens)
@Entity
@Table(name = "users")
public class User {

    @Id
    private UUID userId = UUID.randomUUID();

    private String mail;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Token> tokens = new ArrayList<Token>();

    // constructor vacio
    public User(){}

    // constructor 
    public User(String mail){
        this.mail = mail;
    }

    // getters y setters
    public UUID getUserId() { return userId; }
    public void setUserId(UUID userId) { this.userId = userId; }

    public String getMail() { return mail; }
    public void setMail(String mail) { this.mail = mail; }

    public List<Token> getTokens() { return tokens; }
    public void setTokens(List<Token> tokens) { this.tokens = tokens; }


}
