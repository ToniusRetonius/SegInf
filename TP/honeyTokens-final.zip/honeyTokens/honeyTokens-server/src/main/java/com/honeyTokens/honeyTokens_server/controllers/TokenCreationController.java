package com.honeyTokens.honeyTokens_server.controllers;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.honeyTokens.honeyTokens_server.dtos.TokenRequest;
import com.honeyTokens.honeyTokens_server.dtos.TokenResponse;
import com.honeyTokens.honeyTokens_server.model.Token;
import com.honeyTokens.honeyTokens_server.services.strategies.creation.TokenCreationStrategy;


// recibe el tokenRequest de CLI para generar el token y devolver la url del token generado
// centraliza la accion de "crear el token", dependiendo de que tipo es, consulta el strategyMap 
// y con el service correspondiente hace el create
@RestController
@RequestMapping("/tokens/generate")
public class TokenCreationController {
    
    private final Map<String,TokenCreationStrategy> strategyMap;

    // spring en la creacion inyecta en la lista todos los TokenCreationStrategy y luego en el map
    // hacemos como key su token type y value su service
    @Autowired
    public TokenCreationController(List<TokenCreationStrategy> services){
        this.strategyMap = services.stream().collect(Collectors.toMap(s -> s.getTokenType().toUpperCase(), s -> s));
    }

    // buscamos el servicio, hacemos el create, y con la url creada creamos el response para CLI
    @PostMapping
    public ResponseEntity<TokenResponse> generateToken(@RequestBody TokenRequest request){
        
        
        TokenCreationStrategy strategy = Optional.ofNullable(request.getType())
            .map(String::toUpperCase)        
            .map(strategyMap::get)           
            .orElseThrow(() -> new RuntimeException("Estrategia no encontrada para el tipo: " + request.getType()));

        
        Token newToken = strategy.create(request);
        TokenResponse res = new TokenResponse(newToken.getUrl());

        return ResponseEntity.ok(res);
    }
}
