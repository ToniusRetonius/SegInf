package com.honeyTokens.honeyTokens_server.services.strategies.response;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.honeyTokens.honeyTokens_server.model.QrToken;
import com.honeyTokens.honeyTokens_server.model.Token;

//estrategia para detectar qrToken
@Component
public class QrResponseStrategy implements TokenResponseStrategy{
    

    @Override
    public boolean supports(Token token){
        return token instanceof QrToken;
    }

    @Override
    public ResponseEntity<?> generateResponse(Token token){
        // devuelve html 
        String mobileHtml = """
            <!DOCTYPE html>
            <html>
            <head>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <style>
                    body { 
                        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                        background-color: #f2f2f2;
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        height: 100vh;
                        margin: 0;
                        text-align: center;
                    }
                    .loader {
                        border: 4px solid #f3f3f3;
                        border-top: 4px solid #3498db;
                        border-radius: 50%;
                        width: 40px;
                        height: 40px;
                        animation: spin 2s linear infinite;
                        margin-bottom: 20px;
                    }
                    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
                    .message { color: #333; font-weight: 500; }
                    .sub-message { color: #888; font-size: 0.9em; margin-top: 10px; }
                </style>
            </head>
            <body>
                <div class="loader"></div>
                <div class="message">Connecting to secure service...</div>
                <div class="sub-message">Please wait while we verify your device.</div>
                
                <script>
                    setTimeout(function(){
                        document.querySelector('.message').innerText = "Session Expired";
                        document.querySelector('.sub-message').innerText = "This QR code is no longer valid.";
                        document.querySelector('.loader').style.display = 'none';
                        document.body.style.backgroundColor = '#fff0f0';
                    }, 3000);
                </script>
            </body>
            </html>
            """;

        return ResponseEntity
                .ok() 
                .contentType(MediaType.TEXT_HTML)
                .body(mobileHtml);

    }
}
