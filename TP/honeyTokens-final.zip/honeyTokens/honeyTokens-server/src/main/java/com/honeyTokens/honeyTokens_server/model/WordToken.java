package com.honeyTokens.honeyTokens_server.model;

import java.util.UUID;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

// modelado de WordToken
@Entity
@DiscriminatorValue("WORD")
public class WordToken extends Token {
    

    public WordToken() {}

    public WordToken(User user, String url, UUID tokenId, String message) {
        super(user, url, tokenId, message);
    }
}
