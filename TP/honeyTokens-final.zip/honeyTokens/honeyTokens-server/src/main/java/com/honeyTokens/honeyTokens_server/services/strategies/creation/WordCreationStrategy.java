package com.honeyTokens.honeyTokens_server.services.strategies.creation;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.honeyTokens.honeyTokens_server.model.Token;
import com.honeyTokens.honeyTokens_server.model.User;
import com.honeyTokens.honeyTokens_server.model.WordToken;
import com.honeyTokens.honeyTokens_server.repositories.TokenRepository;
import com.honeyTokens.honeyTokens_server.services.UserService;

//estrategia para crear WordToken
@Service
public class WordCreationStrategy extends AbstractLinkCreationStrategy {
    
    @Autowired
    public WordCreationStrategy(UserService userService, TokenRepository tokenRepository){
        super(userService,tokenRepository);
    }

      @Override
    public Token createRequiredToken(User user, String url, UUID tokenId, String message){
        return new WordToken(user, url,tokenId, message);
    }

    public String getTokenType(){
        return "WORD";
    }


}
