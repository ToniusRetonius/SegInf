package com.honeyTokens.honeyTokens_server.dtos;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

// misma clase para devolver datos a CLI
public class TokenResponse {
    
    private final String finalUrl;
    

    @JsonCreator
    public TokenResponse(@JsonProperty("url") String url){
        this.finalUrl = url;
    }

    public String getUrl(){return finalUrl;}
}
