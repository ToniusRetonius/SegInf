package com.honeyTokens.honeyTokens_server.services.strategies.creation;

import com.honeyTokens.honeyTokens_server.dtos.TokenRequest;
import com.honeyTokens.honeyTokens_server.model.Token;

// interfaz para las estrategias de creacion
public interface TokenCreationStrategy {
    
    public Token create(TokenRequest request);

    public String getTokenType();
}
