package com.honeyTokens.honeyTokens_server.model;

import java.util.UUID;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

//modelado del qrToken
@Entity
@DiscriminatorValue("QR")
public class QrToken extends Token {
    
    public QrToken() {}

    public QrToken(User user, String url, UUID tokenId, String message) {
        super(user, url, tokenId, message);
    }
}
