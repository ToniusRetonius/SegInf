package com.honeyTokens.honeyTokens_server.model;

import java.time.ZonedDateTime;
import java.util.Optional;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.servlet.http.HttpServletRequest;

// modelado de la alerta
@Entity
@Table(name = "alerts")
public class Alert {
    
    @Id
    private UUID alertId = UUID.randomUUID();

    @ManyToOne
    @JoinColumn(name = "tokenId", nullable = false)
    private Token token;
    private String ipClient;
    private String userAgent;
    private String referer;

    @Column(nullable = false)
    private ZonedDateTime timeStamp = ZonedDateTime.now();

    private String url;

    // constructor vacio
    public Alert(){}

    // constructor
    public Alert(Token token,String ip, String userAgent, String referer, String url){
        this.token = token;
        this.ipClient = ip;
        this.userAgent = userAgent;
        this.referer = referer;
        this.url = url;
    }

    // constructor con request
    public static Alert createAlertFromRequest(Token token,HttpServletRequest request){
        String clientIp = Optional.ofNullable(request.getHeader("X-Forwarded-For"))
        .map(s -> s.split(",")[0].trim()).orElse(request.getRemoteAddr());
        

        // Obtener User-Agent
        String userAgent = request.getHeader("User-Agent");

        // Obtener Referer
        String referer = request.getHeader("Referer");

        // Obtener Url
        String url = request.getRequestURL().toString();


        return new Alert(token, clientIp, userAgent, referer, url);

    }

    // getters y setters
    public UUID getAlertId() { return alertId; }
    public void setAlertId(UUID alertId) { this.alertId = alertId; }

    public Token getToken() { return token; }
    public void setToken(Token token) { this.token = token; }

    public String getIpClient() { return ipClient; }
    public void setIpClient(String ipClient) { this.ipClient = ipClient; }

    public String getUserAgent() { return userAgent; }
    public void setUserAgent(String userAgent) { this.userAgent = userAgent; }

    public String getReferer() { return referer; }
    public void setReferer(String referer) { this.referer = referer; }

    public ZonedDateTime getTimeStamp() { return timeStamp; }
    public void setTimeStamp(ZonedDateTime timeStamp) { this.timeStamp = timeStamp; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }

}
