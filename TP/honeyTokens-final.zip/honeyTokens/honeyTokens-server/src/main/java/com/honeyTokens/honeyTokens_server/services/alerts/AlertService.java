package com.honeyTokens.honeyTokens_server.services.alerts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.honeyTokens.honeyTokens_server.model.Alert;
import com.honeyTokens.honeyTokens_server.model.Token;
import com.honeyTokens.honeyTokens_server.repositories.TokenRepository;
import com.honeyTokens.honeyTokens_server.services.EmailService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;

// servicio de alertas para procesarlas
@Service
public class AlertService {
    
    private final EmailService emailService;
    private final TokenRepository tokenRepository;

    @Autowired
    public AlertService(EmailService emailService, TokenRepository tokenRepository){
        this.emailService = emailService;
        this.tokenRepository = tokenRepository;
    }

    @Transactional
    public void processActivation(Token token, HttpServletRequest request){

        if(token.getTimesActivated() > 0){//{ usar para probar el wordToken (word intenta mil veces y lo activa como 30 veces)
           return;
        }

        // avisa que se activo
        System.out.println("token activado!");
        
        // crea la nueva alerta y actualiza el token
        Alert newAlert = Alert.createAlertFromRequest(token,request);
        token.registerActivation(newAlert);
        tokenRepository.save(token);
        try {
            // manda mail 
            emailService.sendAlertMail(token, newAlert);
            } catch (Exception e) {
                System.err.println("ERROR: No se pudo enviar el mail de alerta. " + e.getMessage());
            }
    }
}
