package com.honeyTokens.honeyTokens_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoneyTokensServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
